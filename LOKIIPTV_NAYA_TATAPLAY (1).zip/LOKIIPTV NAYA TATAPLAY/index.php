<!DOCTYPE html>
<head>
  <title>LOKIIPTV</title>
  <meta charset="utf-8">
  <meta name="theme-color" content="#f8f8f8" id="theme-color-meta">
  <meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0, user-scalable=no" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Gloock&display=swap" rel="stylesheet">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Fjalla+One&display=swap" rel="stylesheet">
  <link rel="shortcut icon" href="https://www.jiotv.com/favicon.ico" />
  <link rel="shortcut icon" href="https://iili.io/HiZIZEN.md.jpg" type="image/x-icon">
  <link rel="icon" href="https://iili.io/HiZIZEN.md.jpg" type="image/x-icon">
  <link rel="stylesheet" href="https://ipl-2023-schedule.pages.dev/jtv.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css">
  
  <style>
    /* Header styles */
    @import url("https://fonts.googleapis.com/css2?family=Montserrat&display=swap");

    .header-container {
      display: flex;
      align-items: center;
      font-family: 'Gloock', serif;
      font-weight: bold;
      font-size: 28px;
      color: #333;
      text-align: left;
      text-transform: uppercase;
      letter-spacing: 4px;
      margin-bottom: 20px;
      margin-top: 20px;
      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
      background-color: #f8f8f8;
      padding: 7px 20px;
      border-radius: 20px 20px 20px 20px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
      
    }

    .toggle-wrapper {
  margin-left: auto;
  display: flex;
  align-items: center;
}

    /* Dark mode styles */
    body.dark {
      background-color: #0f172a;
    }

    body.dark .support a {
      color: #fff;
    }

    body.dark .mt-5 {
filter: brightness(90%) contrast(100%); /* Adjust these values as per your preference */
  position: relative;
  z-index: 1;
    }
    
   body.dark .toggle {
        all: unset;
        background-color: darkcyan;
        color: white;
        width: 100px;
        padding-left: 5px;
        padding: 10px;
        font-weight: 700;
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-radius: 10px;
        cursor: pointer;
        right: 10px;
      }
     
     body.dark .btnxd {
        all: unset;
        background-color: darkcyan;
        color: white;
        width: 100px;
        padding: 8px;
        font-weight: 700;
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-radius: 10px;
        cursor: pointer;
        right: 10px;
      }
    body.dark  .list {
       background-color: #334155;
       color: #fff;
       list-style: none;
       display: grid;
       grid-template-rows: repeat(8px, 40px);
       border-radius: 10px;
       overflow: hidden;
       height: 0;
       transition: 0.4s;
     }
    .fa-moon {
      color: #f1c40f;
     font-size:15px;
     margin: 0px -10px 0px 0px;
    }

    .fa-sun {
      color: #f39c12;
      font-size:18px;
      margin: 0px 0px 0px 15px;
    
    }

    /* Add styles for the card in dark mode */
    body.dark .card {
      background-color: #334155;
      /* Choose a suitable dark color for the card */
      color: #fff;
      /* Set the text color to a light color that contrasts with the card background */
    }

    /* Change #tittel color to dark in dark mode */
    body.dark #tittel {
      color: #292c35;
      /* Choose a suitable dark color for #tittel */
    }

    /* Change h1 color, background color, and other styles to dark in dark mode */
    body.dark .header-container {
      color: #fff;
      /* Choose a suitable dark color for h1 text */
      background-color: #334155;
      /* Choose a suitable dark color for h1 background */
      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
      /* Optional: Update the text-shadow for dark mode */
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
      /* Optional: Update the box-shadow for dark mode */
    }

    .checkbox {
      opacity: 0;
      position: absolute;

    }

    .checkbox-label {
      background-color: #111;
      width: 50px;
      height: 26px;
      border-radius: 50px;
      position: relative;
      padding: 5px;
      cursor: pointer;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .checkbox-label .ball {
      background-color: #fff;
      width: 22px;
      height: 22px;
      position: absolute;
      left: 2px;
      top: 2px;
      border-radius: 50%;
      transition: transform 0.2s linear;
    }

    .checkbox:checked+.checkbox-label .ball {
      transform: translateX(24px);
    }

    /* Support me if you like it */
    .support {
      position: absolute;
      right: 20px;
      bottom: 20px;
    }

    .support a {
      color: #292c35;
      font-size: 32px;
      backface-visibility: hidden;
      display: inline-block;
      transition: transform 0.2s ease;
    }

    .support a:hover {
      transform: scale(1.1);
    }
  </style>

  <style>
    /* Dropdown Styles */
    .dropdown {
      position: relative;
      display: inline-block;
    }

    .dropbtn {
      background-color: #007bff;
      color: white;
      padding: 8px;
      font-size: 14px;
      border: ;
      cursor: pointer;
    }

    .dropdown-content {
      display: none;
      position: absolute;
      background-color: #f9f9f9;
      min-width: 160px;
      box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
      z-index: 1;
    }

    .dropdown-content a {
      color: black;
      padding: 12px 16px;
      text-decoration: none;
      display: block;
    }

    .dropdown-content a:hover {
      background-color: #f1f1f1;
    }

    .dropdown:hover .dropdown-content {
      display: block;
    }

    .dropdown:hover .dropbtn {
      background-color: #0056b3;
    }

    /* Dark mode styles for Dropdown */
    body.dark .dropbtn {
      background-color: #292c35;
      color: #fff;
    }

    body.dark .dropdown-content {
      background-color: #444;
      color: #fff;
    }

    body.dark .dropdown-content a {
      color: #fff;
    }

    body.dark .dropdown-content a:hover {
      background-color: #333;
    }

    /* Dark mode styles for .box-shadow */
    body.dark .box-shadow {
      background-color: #444;
      color: #fff;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
    }

    /* Add dark mode styles to the rest of the document (e.g., .header-container, etc.) */
    /* ... */

    body {
      /* display: flex; */
      align-items: center;
      justify-content: center;
      margin: 0 12px;
      height: 100%;
      background-color: #f1f1f1;
    }

    .box-shadow {
      font-family: sans-serif;
      font-weight: 600;
      background-color: #2ecc71;
      color: white;
      padding: 10px;
      border-radius: 4px;
      box-shadow: 2px 2px 20px 23px #7fecad;
      background-color: #f8f8f8;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
      text-align: center;
      font-family: 'Arial', sans-serif;
      font-size: 15px;
      color: #333;
    }

    /*
  .header-container {
    font-family: 'Gloock', serif;
    font-weight: bold;
    font-size: 28px;
    color: #333;
    text-align: left;
    text-transform: uppercase;
    letter-spacing: 4px;
    margin: 20px 0;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    background-color: #f8f8f8;
    padding: 10px 20px;
    border-radius: 10px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
  }
  */

    a. {
      text-decoration: none !important;
    }
  </style>

  <style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap');

    html {
      box-sizing: border-box;
      font-family: 'Poppins', sans-serif;
    }

    *,
    *::after,
    *::before {
      box-sizing: inherit;
      margin: 0;
      padding: 0;
    }

    .option {}

    .containerxd {
      display: inline-flex;
      justify-content: center;
      align-items: flex-start;
      padding-right: 0px;
      padding-bottom: 10px;
    }

    .menu {
      display: grid;
      grid-template-rows: 40px max-content;
      gap: 10px;

    }

    .toggle {
      all: unset;
      background-color: dodgerblue;
      color: white;
      width: 100px;
      padding-left: 5px;
      padding: 10px;
      font-weight: 700;
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-radius: 10px;
      cursor: pointer;
      right: 10px;
    }

    .btnxd {
      all: unset;
      background-color: dodgerblue;
      color: white;
      width: 100px;
      padding: 8px;
      font-weight: 700;
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-radius: 10px;
      cursor: pointer;
      right: 10px;
    }

    .toggle::after {
      content: "";
      width: 6px;
      height: 6px;
      border-width: 0 3px 3px 0;
      border-style: solid;
      transform: rotate(45deg);
      transition: 0.4s;
    }

    .list {
      background-color: white;
      color: #444;
      list-style: none;
      display: grid;
      grid-template-rows: repeat(8px, 40px);
      border-radius: 10px;
      overflow: hidden;
      height: 0;
      transition: 0.4s;
    }

    .list-item {
      display: flex;
      align-items: center;
      padding-left: 5px;
      transition: 0.4s, transform 0.4s var(--delay);
      transform: translateX(-100%);
      user-select: none;
      cursor: pointer;
      height: 40px;
    }

    .list-item:hover {
      background-color: dodgerblue;
      color: #fff;
    }

    .toggle:focus::after {
      transform: rotate(225deg);
    }

    .toggle:focus~.list {
      height: 100%;
    }

    .toggle:focus~.list .list-item {
      transform: translateX(0);
    }

    /* New class to toggle the menu state */
    .menu.opened .list {
      height: 100%;
    }

    .menu.opened .toggle::after {
      transform: rotate(225deg);
    }

    .menu.opened .list-item {
      transform: translateX(0);
    }
  </style>


  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</head>

<body data-sveltekit-preload-data="hover" bis_register="W3sibWFzdGVyIjp0cnVlLCJleHRlbnNpb25JZCI6ImVwcGlvY2VtaG1ubGJoanBsY2drb2ZjaWllZ29tY29uIiwiYWRibG9ja2VyU3RhdHVzIjp7IkRJU1BMQVkiOiJkaXNhYmxlZCIsIkZBQ0VCT09LIjoiZGlzYWJsZWQiLCJUV0lUVEVSIjoiZGlzYWJsZWQiLCJSRURESVQiOiJkaXNhYmxlZCJ9LCJ2ZXJzaW9uIjoiMS45LjEwIiwic2NvcmUiOjEwOTEwfV0=">



  <div style="display: contents">
    <header class="text-gray-600 body-font">
      <div class="header-container">
        <h1 id="title">TATAPLAY</h1>
        <div class="toggle-wrapper">
          <input type="checkbox" class="checkbox" id="checkbox">
          <label for="checkbox" class="checkbox-label">
            <i class="fas fa-moon"></i>
            <i class="fas fa-sun"></i>
            <span class="ball"></span>
          </label>
        </div>
      </div>
      




    </header>

  
  
  
  <main class="">
			<title>LOKIIPTV</title>
			<div class="container">
				<div class="flex flex-row mb-3 ml-1 gap-3 justify-center align-middle" style="margin: 25px;"> <input type="search" id="searchInput" class="relative w-[100%] col-span-4 block mx-4 rounded-l border border-solid border-neutral-300 bg-transparent bg-clip-padding px-3 py-1.5 text-base font-normal text-neutral-700 outline-none transition duration-300 ease-in-out focus:border-primary focus:text-neutral-700 focus:shadow-te-primary focus:outline-none dark:text-neutral-600 dark:placeholder:text-neutral-700" placeholder="Search"></div>
				<div id="listContainer" class="container grid place-items-center grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 2xl:grid-cols-8 mx-auto">
					

<?php
$id = $_GET['id']; // Get the 'id' parameter from the URL

$jsonString = file_get_contents('channel.json');
$jsondatachannel = json_decode($jsonString, true);
$channelsData = $jsondatachannel;
$category = ''; // Define the $category variable

?>

<?php foreach ($channelsData as $channel): ?>
    <?php if ($category === '' || $category === $channel['category']): ?>
  <div class="box1">
    <a href="play.php?id=<?php echo $channel['channel_id']; ?>" data-sveltekit-preload-data="hover">
      <div class="card w-40 bg-gray-100 rounded-xl bg-base-100 shadow-lg h-48 mb-4 flex flex-col">
        <img src="<?php echo $channel['channel_logo']; ?>" style="height:90px;" loading="lazy" class="h-28 mt-5 m-auto opacity-100">
        <div class="mb-5 opacity-100">
          <h2 class="text-center text-sm font-bold"><?php echo $channel['channel_name']; ?></h2>
          <div class="flex justify-center space-x-1">
            <p class="text-xs text-center">LOKIIPTV: <?php echo $channel['channel_genre']; ?></p>
          </div>
        </div>
      </div>
    </a>
  </div>
  <?php endif; ?>
<?php endforeach; ?>

</div>

</div>
        </div>
    </main>
    <div id="svelte-announcer" aria-live="assertive" aria-atomic="true" style="position: absolute; left: 0px; top: 0px; clip: rect(0px, 0px, 0px, 0px); clip-path: inset(50%); overflow: hidden; white-space: nowrap; width: 1px; height: 1px;"></div>
  <script>
  const checkbox = document.getElementById("checkbox")
  checkbox.addEventListener("change", () => {
   document.body.classList.toggle("dark")
  })
 </script>
 
 <script>
    // Get search input element
    const searchInput = document.getElementById('searchInput');

    // Add input event listener
    searchInput.addEventListener('input', filterData);

    // Check if there is a search query in the URL when the page loads
    window.addEventListener('DOMContentLoaded', () => {
        const urlParams = new URLSearchParams(window.location.search);
        const searchQuery = urlParams.get('q');
        if (searchQuery) {
            searchInput.value = searchQuery;
            filterData();
        }
    });

    // Search functionality
    function filterData() {
        const updatedSearchValue = searchInput.value.toLowerCase();

        // Get all box elements
        const boxes = document.querySelectorAll('.box1');

        boxes.forEach((box) => {
            const h2Text = box.querySelector('h2').textContent.toLowerCase();
            const pText = box.querySelector('p').textContent.toLowerCase();

            if (h2Text.includes(updatedSearchValue) || pText.includes(updatedSearchValue)) {
                box.style.display = 'block'; // Show matching box
            } else {
                box.style.display = 'none'; // Hide non-matching box
            }
        });

        // Update the URL with the search query
        const urlParams = new URLSearchParams(window.location.search);
        urlParams.set('q', updatedSearchValue);
        const newUrl = `${window.location.pathname}?${urlParams.toString()}`;
        window.history.replaceState({}, '', newUrl);
    }
</script>
</body>

</html>
